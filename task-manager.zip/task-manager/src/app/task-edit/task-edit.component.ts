import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
    selector: 'app-task-edit',
    templateUrl: './task-edit.component.html',
    styleUrls: ['./task-edit.component.css']
})
export class TaskEditComponent implements OnInit {
    task: any = {};

    constructor(private http: HttpClient, private route: ActivatedRoute, private router: Router) {}

    ngOnInit() {
        const id = this.route.snapshot.paramMap.get('id');
        this.http.get(`http://localhost:3000/tasks/${id}`)
            .subscribe(data => this.task = data);
    }

    editTask() {
        const id = this.route.snapshot.paramMap.get('id');
        this.http.put(`http://localhost:3000/tasks/edit/${id}`, this.task)
            .subscribe(() => this.router.navigate(['/']));
    }
}
