import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
    selector: 'app-task-list',
    templateUrl: './task-list.component.html',
    styleUrls: ['./task-list.component.css']
})
export class TaskListComponent implements OnInit {
    tasks: any = [];

    constructor(private http: HttpClient) {}

    ngOnInit() {
        this.loadTasks();
    }

    loadTasks() {
        this.http.get('http://localhost:3000/tasks')
            .subscribe(data => this.tasks = data);
    }

    deleteTask(id: string) {
        this.http.delete(`http://localhost:3000/tasks/delete/${id}`)
            .subscribe(() => this.loadTasks());
    }
}
