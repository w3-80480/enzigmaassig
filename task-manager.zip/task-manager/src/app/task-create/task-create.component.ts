import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
    selector: 'app-task-create',
    templateUrl: './task-create.component.html',
    styleUrls: ['./task-create.component.css']
})
export class TaskCreateComponent {
    task = { assignedTo: '', status: '', dueDate: '', priority: '', description: '' };

    constructor(private http: HttpClient, private router: Router) {}

    createTask() {
        this.http.post('http://localhost:3000/tasks/create', this.task)
            .subscribe(() => this.router.navigate(['/']));
    }
}
