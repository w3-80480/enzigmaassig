module.exports = {
    MONGO_URI: 'mongodb://localhost:27017/task-manager',
    PORT: 3000
};
